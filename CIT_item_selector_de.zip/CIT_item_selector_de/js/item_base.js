var condition;

var male_names = ['Adam', 'Adrian', 'Alexander', 'Ali', 'Amir', 'Andre', 'Andreas', 'Andrej', 'Anton', 'Armin', 'Arthur', 'Ben', 'Benedikt', 'Benjamin', 'Berat', 'Bernd', 'Bernhard', 'Christian', 'Christoph', 'Christopher', 'Clemens', 'Constantin', 'Daniel', 'David', 'Dominik', 'Elias', 'Emanuel', 'Emil', 'Emir', 'Erik', 'Fabian', 'Fabio', 'Felix', 'Ferdinand', 'Finn', 'Florian', 'Franz', 'Gabriel', 'Georg', 'Gerald', 'Gerhard', 'Gernot', 'Gregor', 'Günther', 'Hamza', 'Hannes', 'Harald', 'Helmut', 'Herbert', 'Jakob', 'Jan', 'Johann', 'Johannes', 'Jonas', 'Jonathan', 'Josef', 'Julian', 'Justin', 'Jürgen', 'Karl', 'Kevin', 'Kilian', 'Klaus', 'Konstantin', 'Laurenz', 'Leo', 'Leon', 'Leonard', 'Leopold', 'Lorenz', 'Manfred', 'Manuel', 'Marcel', 'Marco', 'Mario', 'Markus', 'Martin', 'Marvin', 'Mathias', 'Matthias', 'Max', 'Maximilian', 'Michael', 'Moritz', 'Nico', 'Nicolas', 'Noah', 'Oliver', 'Oskar', 'Pascal', 'Patrik', 'Paul', 'Peter', 'Rafael', 'Reinhard', 'Rene', 'Richard', 'Robert', 'Roland', 'Roman', 'Samuel', 'Sandro', 'Sascha', 'Sebastian', 'Simon', 'Stefan', 'Theo', 'Theodor', 'Thomas', 'Tim', 'Tobias', 'Valentin', 'Viktor', 'Vincent', 'Werner', 'Wolfgang', 'Yusuf'];

var fem_names = ['Alexandra', 'Alina', 'Alma', 'Amelie', 'Amina', 'Ana', 'Anastasia', 'Andrea', 'Angelika', 'Angelina', 'Anita', 'Anja', 'Anna', 'Annika', 'Antonia', 'Astrid', 'Azra', 'Barbara', 'Bernadette', 'Bettina', 'Bianca', 'Birgit', 'Carina', 'Carmen', 'Celine', 'Charlotte', 'Chiara', 'Christina', 'Clara', 'Claudia', 'Cornelia', 'Daniela', 'Denise', 'Doris', 'Ecrin', 'Ela', 'Elena', 'Elif', 'Elina', 'Elisa', 'Elisabeth', 'Ella', 'Emilia', 'Emma', 'Esila', 'Eva', 'Flora', 'Franziska', 'Hanna', 'Helena', 'Hira', 'Ines', 'Iris', 'Isabella', 'Jacqueline', 'Jana', 'Janine', 'Jasmin', 'Jennifer', 'Jessica', 'Johanna', 'Julia', 'Karin', 'Katharina', 'Kerstin', 'Klara', 'Kristina', 'Lara', 'Larissa', 'Laura', 'Lea', 'Lena', 'Leonie', 'Leonora', 'Lilly', 'Lina', 'Linda', 'Lisa', 'Magdalena', 'Maja', 'Manuela', 'Marie', 'Marina', 'Martina', 'Matilda', 'Maya', 'Melanie', 'Melina', 'Melissa', 'Mia', 'Michelle', 'Mila', 'Mira', 'Miriam', 'Monika', 'Nadine', 'Natalie', 'Natascha', 'Nicole', 'Nina', 'Nisa', 'Nora', 'Olivia', 'Patricia', 'Paula', 'Paulina', 'Petra', 'Pia', 'Rebecca', 'Romana', 'Rosa', 'Sabine', 'Sandra', 'Sara', 'Selina', 'Silke', 'Silvia', 'Simone', 'Sofia', 'Sonja', 'Sophie', 'Stefanie', 'Stella', 'Susanne', 'Tamara', 'Tanja', 'Teodora', 'Teresa', 'Theresa', 'Tina', 'Valentina', 'Valerie', 'Vanessa', 'Verena', 'Veronika', 'Viktoria', 'Yvonne', 'Zoe'];

var animls = ["Alligator", "Alpaka", "Ameise", "Antilope", "Dachs", "Fledermaus", "Bär", "Biber", "Biene", "Bison", "Schmetterling", "Kamel", "Katze", "Raupe", "Gepard", "Huhn", "Schimpanse", "Kobra", "Krabbe", "Kranich", "Krokodil", "Krähe", "Hirsch", "Hund", "Delfin", "Esel", "Taube", "Ente", "Adler", "Elefant", "Emu", "Frettchen", "Flamingo", "Fliege", "Fuchs", "Frosch", "Gazelle", "Giraffe", "Gnu", "Ziege", "Gans", "Gorilla", "Heuschrecke", "Hamster", "Falke", "Igel", "Hering", "Nilpferd", "Pferd", "Kolibri", "Hyäne", "Schakal", "Jaguar", "Qualle", "Känguru", "Kiwi", "Koala", "Lemur", "Leopard", "Löwe", "Lama", "Hummer",  "Elster", "Mammut", "Maulwurf", "Mungo", "Affe", "Elch", "Maus", "Mücke", "Oktopus", "Opossum", "Eule", "Auster", "Panther", "Papagei", "Panda", "Pelikan", "Pinguin", "Fasan", "Schwein", "Taube", "Stachelschwein", "Schweinswale", "Kaninchen", "Waschbär", "Widder", "Ratte", "Rabe", "Rentier", "Nashorn", "Salamander", "Lachs", "Siegel", "Hai", "Schaf", "Faultier", "Schnecke", "Schlange", "Spinne", "Schwan", "Tapir", "Tiger", "Kröte", "Truthahn", "Walross", "Wespe", "Wiesel", "Wal", "Wolf", "Wombat", "Zebra"];

var animls_orig=["Alligator", "Alpaca", "Ant", "Antelope", "Badger", "Bat", "Bear", "Beaver", "Bee", "Bison", "Buffalo", "Butterfly", "Camel", "Cat", "Caterpillar", "Cheetah", "Chicken", "Chimpanzee", "Cobra", "Crab", "Crane", "Crocodile", "Crow", "Deer", "Dog", "Dolphin", "Donkey", "Dove", "Duck", "Dugong", "Eagle", "Elephant", "Emu", "Falcon", "Ferret", "Flamingo", "Fly", "Fox", "Frog", "Gazelle", "Giraffe", "Gnu", "Goat", "Goose", "Gorilla", "Grasshopper", "Hamster", "Hawk", "Hedgehog", "Herring", "Hippopotamus", "Horse", "Hummingbird", "Hyena", "Jackal", "Jaguar", "Jellyfish", "Kangaroo", "Kiwi", "Koala", "Lemur", "Leopard", "Lion", "Llama", "Lobster", "Locust", "Magpie", "Mammoth", "Mole", "Mongoose", "Monkey", "Moose", "Mouse", "Mosquito", "Octopus", "Opossum", "Ostrich", "Owl", "Oyster", "Panther", "Parrot", "Panda", "Pelican", "Penguin", "Pheasant", "Pig", "Pigeon", "Porcupine", "Porpoise", "Rabbit", "Raccoon", "Ram", "Rat", "Raven", "Reindeer", "Rhinoceros", "Salamander", "Salmon", "Seahorse", "Seal", "Shark", "Sheep", "Sloth", "Snail", "Snake", "Spider", "Squirrel", "Swan", "Tapir", "Tiger", "Toad", "Turkey", "Walrus", "Wasp", "Weasel", "Whale", "Wolf", "Wolverine", "Wombat", "Yak", "Zebra"];

var nums = range(1, 32);

capitalize = function(str1){
  return str1.charAt(0).toUpperCase() + str1.slice(1);
}

animls.forEach(function(item, index) {
    animls[index] = item.toLowerCase();
});
animls.sort();

var items_base1 = [ [ "jan", "feb", "mar", "apr", "mai", "jun", "jul", "aug", "sep", "okt", "nov", "dez" ], nums, animls.sort()
];

var categories_base = [ "months", "days", "animals"];
var categories = [ "dates", "animals", "firstnames" ];

$( document ).ready( function() {
    categories_base.forEach( function( categ, index ) { //fills up the selection options for the categories
        var dropChoices = '';
        var catAll = items_base1[ index ];
        catAll.forEach( function( word ) {
            dropChoices += '<option value="' + word + '">' + word + '</option>';
        } );
        categ_id = "#" + categ;
        $( categ_id ).append( dropChoices );
    } );
} );

var actual_probes, items_base2, firstnames;
function prune() {
    gender = $("input[name=gender]:checked").val();
    if (gender == 1) {
        firstnames = male_names;
    } else {
        firstnames = fem_names;
    }
    firstnames.forEach(function(item, index) {
        firstnames[index] = item.toLowerCase();
    });
    firstnames.sort();
    items_base1.push(firstnames);
    //given the probe (in each of the categories), selects 8 additional items, 5 of which will later be irrelevants. None with same starting letter, and with length closest possible to the probe.
    var actual_probes_base = [
        $("#months")
            .val()
            .toLowerCase(),
        $("#days").val(),
        $("#animals")
            .val()
            .toLowerCase(),
        $("#firstname_id")
            .val()
            .toLowerCase()
    ];
    actual_probes = [
        [actual_probes_base[0], actual_probes_base[1]].join(" "),
        actual_probes_base[2], actual_probes_base[3]
    ];
    var items_base2_temp = [];
    actual_probes_base.forEach(function(probe, index) {
        var container = items_base1[index],
            temps;
        var final8 = [probe];
        var maxdif = 0;
        if (probe[0] > -1) {
            final8.push.apply(final8, [0, 0, 0, 0, 0, 0, 0]);
        } else {
            container = $.grep(container, function(n) {
                return probe != n;
            });
            container = $.grep(container, function(n) {
                return probe[0] != n[0];
            });
            while (final8.length < 9 && maxdif < 99) {
                temps = $.grep(container, function(n) {
                    return Math.abs(probe.length - n.length) <= maxdif;
                });
                if (temps.length > 0) {
                    final8.push(rchoice(temps));
                    container = $.grep(container, function(n) {
                        return final8[final8.length - 1] !== n;
                    });
                    if (index === 2 || index === 3) {
                        container = $.grep(container, function(n) {
                            return final8[final8.length - 1][0] !== n[0];
                        });
                    }
                } else {
                    maxdif++;
                }
            }
        }
        items_base2_temp.push(final8);
    });
    var days = range(1, 32);
    var day;
    var days_to_filt1 = [actual_probes_base[1]];
    items_base2_temp[0].forEach(function(month, index) {
        if (index > 0) {
            var days_to_filt2 = days_to_filt1;
            if (month == "feb") {
                days_to_filt2 = days_to_filt1.concat([29, 30, 31]);
            } else {
                if (
                    $.inArray(month, [
                        "apr",
                        "jun",
                        "sep",
                        "nov"
                    ]) > -1
                ) {
                    days_to_filt2.push(31);
                }
            }
            var dys_temp = $.grep(days, function(a) {
                return $.inArray(a, days_to_filt2) == -1;
            });
            day = rchoice(dys_temp);
        } else {
            day = items_base2_temp[1][0];
        }
        day = day.toString();
        if (day.length == 1) {
            day = "0" + day;
        }
        items_base2_temp[0][index] = [month, day].join(" ");
        days_to_filt1.push(day);
    });
    items_base2_temp.splice(1, 1);
    items_base2 = items_base2_temp;
    select_meaningful();
}


function select_meaningful() {
    window.countC0 = 0;
    window.countC1 = 0;
    window.countC2 = 0;
    window.words_to_filter = [
        [],
        [],
        []
    ];
    items_base2.forEach( function( categ, index1 ) {
        column = categ.slice( 1, 9 );
        column.forEach( function( word, ind ) {
            column[ ind ] = word.toLowerCase();
        } );
        column.sort();
        column.splice( 8, 0, "Keine" );
        column.forEach( function( word, index2 ) {
            var id_full = [ "#wo", index1, index2 ].join( "" );
            $( id_full ).text( word );
        } );
    } );
    $( ".words0" ).click( function() {
        var this_word = $( this ).text();
        if ( this_word == "Keine" ) {
            if ( $( this ).hasClass( 'turnedon' ) ) {
                $( this ).removeClass( 'turnedon' );
                countC0 = 0;
            } else {
                if ( countC0 === 0 ) {
                    $( this ).addClass( 'turnedon' );
                    countC0 = 9;
                }
            }
        } else {
            if ( $( this ).hasClass( 'turnedon' ) ) {
                $( this ).removeClass( 'turnedon' );
                words_to_filter[ 0 ] = $.grep( words_to_filter[ 0 ], function( a ) {
                    return a != this_word;
                } );
                countC0--;
            } else {
                if ( countC0 < 2 ) {
                    $( this ).addClass( 'turnedon' );
                    words_to_filter[ 0 ].push( this_word );
                    countC0++;
                }
            }
        }
    } );
    $( ".words1" ).click( function() {
        var this_word = $( this ).text();
        if ( this_word == "Keine" ) {
            if ( $( this ).hasClass( 'turnedon' ) ) {
                $( this ).removeClass( 'turnedon' );
                countC1 = 0;
            } else {
                if ( countC1 === 0 ) {
                    $( this ).addClass( 'turnedon' );
                    countC1 = 9;
                }
            }
        } else {
            if ( $( this ).hasClass( 'turnedon' ) ) {
                $( this ).removeClass( 'turnedon' );
                words_to_filter[ 1 ] = $.grep( words_to_filter[ 1 ], function( a ) {
                    return a != this_word;
                } );
                countC1--;
            } else {
                if ( countC1 < 2 ) {
                    $( this ).addClass( 'turnedon' );
                    words_to_filter[ 1 ].push( this_word );
                    countC1++;
                }
            }
        }
    } );
    $( ".words2" ).click( function() {
        var this_word = $( this ).text();
        if ( this_word == "Keine" ) {
            if ( $( this ).hasClass( 'turnedon' ) ) {
                $( this ).removeClass( 'turnedon' );
                countC2 = 0;
            } else {
                if ( countC2 === 0 ) {
                    $( this ).addClass( 'turnedon' );
                    countC2 = 9;
                }
            }
        } else {
            if ( $( this ).hasClass( 'turnedon' ) ) {
                $( this ).removeClass( 'turnedon' );
                words_to_filter[ 2 ] = $.grep( words_to_filter[ 2 ], function( a ) {
                    return a != this_word;
                } );
                countC2--;
            } else {
                if ( countC2 < 2 ) {
                    $( this ).addClass( 'turnedon' );
                    words_to_filter[ 2 ].push( this_word );
                    countC2++;
                }
            }
        }
    } );
}

var stim_base = [];
function create_stim_base() {
    //creates all stimuli (a 6-item group - 1probe,1target,4irrelevants - for each of 4 different categories) from the given item and probe words
    items_base2.forEach(function(categ, index) {
        var filtered_words = $.grep(categ, function(a) {
            return $.inArray(a, words_to_filter[index]) == -1;
        });
        var words_array = [];
        if (true) { // always true here - Python will decide condition
            words_array = [filtered_words[0]].concat(
                shuffle(filtered_words.slice(1, 7))
            ); // for GUILTY
        } else {
            words_array = shuffle(filtered_words.slice(1, 7)); // for INNOCENT
        }
        words_array.forEach(function(worrd, index) {
            words_array[index] = capitalize(worrd);
        });
        stim_base.push(words_array);
    });
    console.log(stim_base[0]);
    console.log(stim_base[1]);
    ready_stims = true;
    for_py = "firstnames = [u'" + stim_base[2].join("', u'") + "']";
    for_py += "\ndates = [u'" + stim_base[0].join("', u'") + "']";
    for_py += "\nanimals = [u'" + stim_base[1].join("', u'") + "']";
    console.log(for_py);
    for_py2 = "firstnames = [u'" + stim_base[2].join("', u'") + "']";
    for_py2 += "<br>dates = [u'" + stim_base[0].join("', u'") + "']";
    for_py2 += "<br>animals = [u'" + stim_base[1].join("', u'") + "']";
    element = $('<textarea>').appendTo('body').val(for_py).select();
    document.execCommand("Copy");
    element.remove();
}
var ready_stims = false;
var for_py,for_py2;
$(document).ready(function() {
    $(document).keyup(function(es) {
        //starting screen
        if (ready_stims === true) {
            keys_code = es.keyCode || es.which;
            if (keys_code == 69 || keys_code == 73) {
                $("#instructions").html(for_py2);
            }
        }
    });
});
